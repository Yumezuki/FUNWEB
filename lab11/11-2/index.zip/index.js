

const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const app = express();
const port = 3000;

app.use((req, res, next) => {
    res.setHeader("Content-Security-Policy",
        "default-src 'self'; " +
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; " +
        "script-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; " +
        "img-src 'self' data: blob:;");
    next();
});

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.use(express.urlencoded({ extended: true }));

const db = new sqlite3.Database('./todos.db', (err) => {
    if (err) {
        console.error(err.message);
    } else {
        console.log('Connected to SQLite database.');
        db.run(`CREATE TABLE IF NOT EXISTS todos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            deadline TEXT,
            status INTEGER DEFAULT 0
        )`);
    }
});

// ดึงข้อมูลทั้งหมดและแสดงผลในหน้าเว็บ
app.get('/', (req, res) => {
    db.all('SELECT * FROM todos', [], (err, rows) => {
        if (err) {
            res.status(500).send(err.message);
            return;
        }
        res.render('show', { todos: rows });
    });
});

// เพิ่ม Todo ใหม่ผ่านฟอร์ม
app.post('/todos', (req, res) => {
    const { title, description, deadline } = req.body;
    db.run(`INSERT INTO todos (title, description, deadline, status) VALUES (?, ?, ?, ?)`,
        [title, description, deadline, 0],
        function (err) {
            if (err) {
                res.status(500).send(err.message);
                return;
            }
            res.redirect('/');
        });
});

// อัปเดตสถานะของ Todo
app.post('/todos/:id/complete', (req, res) => {
    const { id } = req.params;
    db.run(`UPDATE todos SET status = 1 WHERE id = ?`,
        [id],
        function (err) {
            if (err) {
                res.status(500).send(err.message);
                return;
            }
            res.redirect('/');
        });
});

// ลบ Todo
app.post('/todos/:id/delete', (req, res) => {
    const { id } = req.params;
    db.run(`DELETE FROM todos WHERE id = ?`, id, function (err) {
        if (err) {
            res.status(500).send(err.message);
            return;
        }
        res.redirect('/');
    });
});

app.get('/form', (req, res) => {
    res.render('form');
});

app.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});
