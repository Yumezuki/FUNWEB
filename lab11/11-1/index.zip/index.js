const express = require("express");
const path = require("path");
const port = 3000;
const sqlite3 = require('sqlite3').verbose();

// Creating the Express server
const app = express();

// Connect to SQLite database
// let db = new sqlite3.Database('', (err) => {
//     if (err) {
//         return console.error(err.message);
//     }
//     console.log('Connected to the database.');
// });


// static resourse & templating engine
app.use(express.static('public'));
// Set EJS as templating engine
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

app.use(express.json())
app.use(express.urlencoded({ extended: true }))

app.get("/countries", async (req, res) => {
    const endpoint = 'http://10.0.15.21:8000/countries';

    try {
        const response = await fetch(endpoint);
        const countries = await response.json();
        res.render('show', { data: countries });
    } catch (error) {
        console.error("Error fetching countries:", error);
        res.status(500).send("Error fetching country data.");
    }
});


app.listen(port, () => {
    console.log(`Starting node.js at port ${port}`);
});