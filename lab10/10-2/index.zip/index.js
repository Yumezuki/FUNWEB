const express = require("express");
const sqlite3 = require("sqlite3").verbose();
const path = require("path");

const app = express();
const PORT = 3000;

// ตั้งค่า EJS เป็น view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// เชื่อมต่อฐานข้อมูล SQLite
const db = new sqlite3.Database("questions.db", sqlite3.OPEN_READONLY, (err) => {
    if (err) {
        console.error("Error opening database:", err.message);
    } else {
        console.log("Connected to database.");
    }
});

// ดึงข้อมูลข้อสอบทั้งหมดจากฐานข้อมูล
app.get("/", (req, res) => {
    const sql = "SELECT * FROM questions";
    db.all(sql, [], (err, rows) => {
        if (err) {
            console.error("Error fetching questions:", err.message);
            res.status(500).send("Error fetching questions");
            return;
        }
        res.render("show", { questions: rows });
    });
});

// เรียกใช้งานเซิร์ฟเวอร์
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
