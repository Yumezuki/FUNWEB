const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const port = 3000;

// เชื่อมต่อกับฐานข้อมูล SQLite
let db = new sqlite3.Database("userdata.db", (err) => {
    if (err) {
        return console.error(err.message);
    }
    console.log("Connected to database.");
});

// ตั้งค่า static files และ templating engine
app.use(express.static("public"));
app.set("view engine", "ejs");

// แสดงรายการ Users ทั้งหมด
app.get("/", (req, res) => {
    const sql = "SELECT * FROM users";
    db.all(sql, [], (err, rows) => {
        if (err) {
            return console.error(err.message);
        }
        res.render("show", { users: rows });
    });
});

// แสดงรายละเอียดของ User ตาม ID
app.get("/user/:id", (req, res) => {
    const sql = "SELECT * FROM users WHERE id = ?";
    db.get(sql, [req.params.id], (err, row) => {
        if (err) {
            return console.error(err.message);
        }
        res.render("details", { user: row });
    });
});

// เริ่มเซิร์ฟเวอร์
app.listen(port, () => {
    console.log(`Server started on http://localhost:${port}`);
});
